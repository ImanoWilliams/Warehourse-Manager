
package warehousemanager;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * File Name: Widget.java
 * Author: Imano Williams
 * Course: COMP755 and Section: 001 
 * Date: September 31, 2014
 * This class represent the information about a shipment or an order object.It
 * also, has creates a toSting method that returns the process order and the 
 * shipments associated with the order.
 */
public class Widget {
    
    private char widgetType;
    //stores the amount of widget for the shipment or order
    private int amountOfWidget;
    //stores the cost of a widget for the shipment or order
    private double costOfWidget;
    //stores the vendor of the shipment or order
    private String vendor;
    //stores the amount of widgets are remaining for an order
    private int widgetsLeftForProcess;
    private ArrayList<ShipmentsToOrder> shipmentsToOrder;
    DecimalFormat df = new DecimalFormat("0.00##");
    
    /**
     * The shipment widget constructor
     * @param widgetType
     * @param amountOfWidget
     * @param costOfWidget
     * @param vendor
     */
    public Widget(char  widgetType, int amountOfWidget, double 
            costOfWidget, String vendor){
        this.widgetType=widgetType;
        this.amountOfWidget=amountOfWidget;
        this.costOfWidget=costOfWidget;
        this.vendor=vendor;        
    }

    /**
     * The order widget constructor
     * @param widgetType
     * @param amountOfWidget
     * @param vendor
     */
    public Widget(char widgetType, int amountOfWidget, 
            String vendor){
        this.widgetType=widgetType;
        this.amountOfWidget=amountOfWidget;
        this.widgetsLeftForProcess=amountOfWidget;
        this.costOfWidget=0.0;
        this.vendor=vendor;  
        this.shipmentsToOrder=new ArrayList<>();
    }
    
    /**
     * 
     * @return The type of  widget, either shipment or order.
     */
    public char getWidgetType(){
        return widgetType;
    }
    
    /**
     *
     * @return The amount of widgets for a shipment or an order.
     */
    public int getAmountOfWidget(){
        return amountOfWidget;
    }
    
    /**
     * 
     * @param amount 
     */
    public void setAmountOfWidget(int amount){
        amountOfWidget = amount;
    }
    
    /**
     * 
     * @return The amount of widgets left to be process for a specific order.
     */    
    public int getRemainingWidgets(){
        return widgetsLeftForProcess;
    }
    
    /**
     * Reduce the amount of widgets to the amount left to be processed.
     * @param amount The amount to reduce a specific order amount by.
     */
    public void setRemainingWidgets(int amount){
        widgetsLeftForProcess -= amount;
    }

    /**
     *
     * @return The cost of the shipment or order. 
     */
    public double getCostOfWidget (){
        return costOfWidget;
    }
    
    /**
     * Set the Cost of an widgets order.
     * @param cost The cost of the shipment cost per amount of widgets for the
     * order.
     */
    public void setCostOfWidget(double cost){
        costOfWidget+=cost;
    }
    
    /**
     *
     * @return The vendor name of the shipment or order. 
     */
    public String getVendor(){
        return vendor;
    }
    
    /**
     * Maps the shipment to order ArrayList for each of the shipments 
     * related to order. 
     * @return A String of all the orders that were part of filling the order.
     */
    protected String printShipments(){
        String x="";
        x = shipmentsToOrder.stream().map((shipmentsToOrder1) -> 
                shipmentsToOrder1.toString()).reduce(x, String::concat);
        return x;
    }
   
    /**
     * Creates a the Shipment object that related to an order, and add it
     * to an Shipment to Order ArrayList. 
     * @param amountWidgetsUsed The amount of widgets used for the order
     * @param CostOfShipment The amountWidgetsUsed times the cost of the widget
     * for the order
     * @param orderVendor The vendor that was used to fill the order
     */
    protected void addShipment(int amountWidgetsUsed, double CostOfShipment, 
            String orderVendor){
        
        shipmentsToOrder.add(new ShipmentsToOrder(amountWidgetsUsed,CostOfShipment,
                orderVendor));
        
    }
    
    /**
     * 
     * @return The string representation of an order and the shipments that are
     * related to the order.
     */
    @Override
    public String toString(){
        return  this.getVendor()+"\t\t"+
                this.getAmountOfWidget()+"\t\t"+
                df.format(this.getCostOfWidget())+"\n"+ this.printShipments();
    }
    
}
