package warehousemanager;

import java.util.NoSuchElementException;

/**
 * File Name: WarehouseStack.java
 * Author: Imano Williams
 * Course: COMP755 and Section: 001 
 * Date: September 31, 2014
 * This class defines a stack class using LinkedList that can add, remove or 
 * peek at an element in the stack.
 */
class WarehouseStack{
    protected LinkedList topOfStack ;    
 
   /**
    * Stack Constructor that initialize the top of the stack to be
    * null.
    */
    public WarehouseStack(){
        topOfStack = null;        
    }    
    
    /**
     * Method to push an element to the stack 
     * @param widget to be push onto the topOfStack of the stack.
     */   
    public void push(Widget widget){
        LinkedList nodeLink = new LinkedList (widget, null);
        if (topOfStack == null)
            topOfStack = nodeLink;
        else
        {
            nodeLink.setLink(topOfStack);
            topOfStack = nodeLink;
        }        
    }
    
    /**
     * Method to pop an element from the stack.
     * @return widget object
     */    
    public Widget pop(){
        if (topOfStack == null){
            throw new NoSuchElementException("Underflow Exception") ;
        }        
        LinkedList link = topOfStack;
        topOfStack = link.getLink();                
        return link.getWidget();
    } 
    /**
     * Method to check the topOfStack element of the stack 
     * @return widget object
     */    
    public Widget peek(){
        if (topOfStack == null)
            return null;//throw new NoSuchElementException("Underflow Exception") ;
        return topOfStack.getWidget();
    } 
}
 

