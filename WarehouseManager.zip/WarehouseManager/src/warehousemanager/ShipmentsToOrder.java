package warehousemanager;

/**
 * File Name: Widget.java
 * Author: Imano Williams
 * Course: COMP755 and Section: 001 
 * Date: September 31, 2014
 * This class represent the information about a shipment that is related to an
 * order.
 */
public class ShipmentsToOrder {
    //The amount of widgets used for the order.
    private int amount;
    //The amountWidgetsUsed times the cost of the widget
    //for the order
    private double cost;
    //The vendor that was used to fill the order
    private String vendor;
    
    /**
     * Shipment to Order Constructor.
     * @param amount
     * @param cost
     * @param vendor 
     */
    public ShipmentsToOrder(int amount, double cost, String vendor){
       this.amount=amount;
       this.cost=cost;
       this.vendor=vendor;
        
    }      
    
    /**
     * 
     * @return The a string representation of the ShipmentsToOrder object.
     */
    @Override
    public String toString(){
        return "\t"+this.amount+"\t\t"+this.cost+"\t"+this.vendor+"\n";
    }
    
}
