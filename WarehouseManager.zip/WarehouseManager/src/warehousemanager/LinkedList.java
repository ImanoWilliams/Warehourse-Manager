package warehousemanager;

/**
 * File Name: LinkedList.java
 * Author: Imano Williams
 * Course: COMP755 and Section: 001 
 * Date: September 31, 2014
 * This class defines a LinkedList Object.
 */
class LinkedList{
    
    protected Widget widget;
    protected LinkedList link;
    
    /**
     * LinkedList Constructor
     * @param widget
     * @param nextNode 
     */ 
    public LinkedList(Widget widget,LinkedList nextNode){
        this.widget = widget;
        link = nextNode;
    } 
    
    /** 
     * Method to set link to next Node
     * @param nextNode 
     */
    
    public void setLink(LinkedList nextNode){
        link = nextNode;
    } 
    
    /**
     * Method to set widget to current Node
     * @param widget 
     */
    
    public void setData(Widget widget){
        this.widget = widget;
    } 
    /**
     * Method to get link to next node 
     * @return 
     */
    
    public LinkedList getLink(){
        return link;
    }
    
    /**
     * Method to get widget from current Node
     * @return a widget object from the LinkedList
     */
    
    public Widget getWidget(){
        return this.widget;
    }
}