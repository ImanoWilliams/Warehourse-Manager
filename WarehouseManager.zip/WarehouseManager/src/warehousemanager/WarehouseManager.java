package warehousemanager;

import java.io.File;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * File Name: WarehouseManager.java
 * Author: Imano Williams
 * Course: COMP755 and Section: 001 
 * Date: September 31, 2014
 * This file takes in two text files, one to receive warehouse shipments and 
 * orders, an the other to accept the processing of the input file. The user is
 * prompted for the input file to choose from. 
 */
public class WarehouseManager {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        
        Scanner in = new Scanner(System.in);
        int inputtextFileUse=0;
        boolean input=true;
        File inputFile=new File("BlankFile");
        File outputFile = new File("BlankFile");
        
        //Continuously display to the user the input file to choose from.
        while(input){
            try{
                System.out.print("File hw1in.txt=1.\n"
                        + "File hw2in.txt=2.\n"
                        + "Enter 1 or 2 for the input file to read from:");
                //Scan in the 
                inputtextFileUse = in.nextInt();
                if(!(inputtextFileUse<1 ||inputtextFileUse>2)){
                    input=false;
                    break;
                } 
                System.out.println("Please follow directions!  "
                        + "Enter a single digit(1-2)!");
            }
            // Catch the user invalid input
            catch (InputMismatchException ime) {
                //skips over the invalid characters that are sitting input
                //stream
                input=true;
                in.skip(".*"); 
                System.out.println("Please follow directions!  "
                        + "Enter a single digit(1-2)!");
            }
        }
        
        switch(inputtextFileUse){
            case 1:{
                inputFile = new File("hw1in.txt");
                outputFile = new File("hw1out.txt");
                break;
            }
            case 2:{
                inputFile = new File("hw2in.txt");
                outputFile = new File("hw2out.txt");
                break;
            }
        }
        //create an Inventory object with the input and output file and then 
        //process the widgets in the input file.
        if(inputFile.exists()){            
        InventoryManager inventoryManager = new InventoryManager(inputFile,outputFile);        
        inventoryManager.processFile();
        }
        else if(!inputFile.exists()){
            System.out.println("No file exists with that name.\n\nPlease enter"
                    + " a valid file name.Program terminated.");
        }
    }
    
}
