package warehousemanager;

import java.util.NoSuchElementException;

/**
 * File Name: WarehouseQueue.java
 * Author: Imano Williams
 * Course: COMP755 and Section: 001 
 * Date: September 31, 2014
 * This class defines a queue class using LinkedList that can add, remove or 
 * peek at an element in the queue.  
 */
class WarehouseQueue{
    protected LinkedList frontOfQueue, rearOfQueue;
    //public int size;
 
    /**
     * Queue Constructor that initialize the front an d back of the queue to be
     * null.
     */
    public WarehouseQueue(){
        frontOfQueue = null;
        rearOfQueue = null;        
    }      
     /**
      * Function to insert an element to the back OfQueue of the queue.
      * @param widget widget object to be added to the queue.
      */     
    public void enqueue(Widget widget){
        LinkedList nodeLink = new LinkedList(widget, null);
        if (rearOfQueue == null)
        {
            frontOfQueue = nodeLink;
            rearOfQueue = nodeLink;
        }
        else
        {
            rearOfQueue.setLink(nodeLink);
            rearOfQueue = rearOfQueue.getLink();
        }       
    } 
    /**
     * Method to remove frontOfQueue element from the front of the queue.
     * @return The widget object.
     */    
    public Widget dequeue(){
        if (frontOfQueue == null)
           throw new NoSuchElementException("Underflow Exception");
        LinkedList link = frontOfQueue;
        frontOfQueue = link.getLink();        
        if (frontOfQueue == null)
            rearOfQueue = null;              
        return link.getWidget();
    }  
    /**
     * Method to get the frontOfQueue element from the front of the queue.
     * @return 
     */   
    public Widget peek(){
        if (frontOfQueue == null){           
           return null;
        }        
        return frontOfQueue.getWidget();
    }      
}