package warehousemanager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.NoSuchElementException;

/**
 * File Name: Inventory.java
 * Author: Imano Williams
 * Course: COMP755 and Section: 001 
 * Date: September 31, 2014
 * This class process the shipments and orders from a file as they come in and 
 * then writes the processed orders to a file. If there are no
 * waiting order that shipment is place on a stack.If there is no shipment when 
 * an order comes in or if not enough shipment to satisfy the order, the order 
 * is place in a waiting queue.Also, write the orders that are pending to the 
 * file.Additionally, if there is an invalid data in the file, method process
 * file handles it and display which line the error(s) occur(s). 
 */
public class InventoryManager {
    //Stack to store the shipment widgets.
    WarehouseStack shipment = new WarehouseStack();
    //Queue to store order widgets to be completed.
    WarehouseQueue order = new WarehouseQueue();
    //Shipment object to store information about widgets
    Widget widgetShipment;
    //Order object to store information about widgets
    Widget widgetOrder;
    //Value use to track the total amount of order widgets in the warehouse 
    int totalOrderOfWidgets = 0;
    //Value use to track the total amount of shipments widgets in the warehouse 
    int totalShipmentOfWidgets = 0;
    //Set a new in the file.
    String eol = System.getProperty("line.separator"); 
    //File object to hold the input file to be process.
    File inputFile;
    //Reader object to read from input file
    BufferedReader inputFileBuffer;
    //File object to hold the output file to be process.
    File outputFile;
    //Writer object to write to output file
    BufferedWriter outputFileBuffer;
    //Tax multiplier for the orderd goods
    final double TAX;
    
    /**
     * Inventory Constructor that takes accepts two files to be process
     * from the warehouse and also initialize BufferReader and BufferWirter.
     * @param inputFile
     * @param outputFile
     * @throws IOException
     */
    public InventoryManager(File inputFile, File outputFile) throws IOException{
        this.TAX = 1.50;
        this.inputFile=inputFile;
        this.outputFile=outputFile; 
        outputFileBuffer = new BufferedWriter
        (new FileWriter(this.outputFile));
        inputFileBuffer = new BufferedReader(new FileReader(
                this.inputFile));
    }
    
    
    /**
     * Process the input file, one line at time to get each order or shipment
     * information. If there errors in the file at a particular line, that line 
     * is skip. This method also takes care of invalid information, such as data
     * from file cannot be parse to the right type or if there are blank spaces
     * where there should be information.
     * @throws java.io.FileNotFoundException
     */
    protected void processFile() throws FileNotFoundException,IOException{
        String line;//line to read inputs from
        String trimLine;
        int lineCounter=0;
        /**
        * Loop through the input file until all lines in the file are read.
        */
        while ((line = inputFileBuffer.readLine()) != null){
            lineCounter++;
            //Sting to store the each attributes about a shipment or an order
            //"\\s+" takes care of whitespaces between each attributes
            trimLine = line.trim();
            //checks that the trimmed line is not blank before processing that 
            //line
            if(!trimLine.equals("")){
            String datavalue[] = trimLine.split("\\s+");
            //gets the first value from the readline             
            char widgetType = datavalue[0].charAt(0);
            int widgetAmount;
            double widgetCost;
            String widgetName;
            //check wether an Order or Shipment
            switch (widgetType) {
                case 's':{   
                    try{ //try and catch invalid data from the file
                        //in this case the line where the error occurred
                        //will not be processed.
                        widgetAmount = Integer.parseInt(datavalue[1]);                            
                        widgetCost = Double.parseDouble(datavalue[2]);                            
                        widgetName = datavalue[3].trim();
                        if(widgetName.length()==0){
                            throw new NumberFormatException();
                        }
                        widgetShipment = new Widget(widgetType,widgetAmount,
                                    widgetCost,widgetName);
                        processShipment();
                        break;
                    }
                    catch(NumberFormatException ex){ // handle your exception
                        System.out.println("Error in Line "+lineCounter 
                                        +" : "+line);
                        break;
                    }                        
                }
                case 'o':{
                        try{//try and catch invalid data from the file
                            //in this case the line where the error occurred
                            //will not be processed.
                            widgetAmount= Integer.parseInt(datavalue[1]);
                            widgetName = datavalue[2].trim();
                            if(widgetName.length()==0){
                                throw new NumberFormatException();
                            }
                            widgetOrder = new Widget(widgetType,widgetAmount, widgetName);
                            processOrder();
                            break;                             
                            }                            
                            catch(NumberFormatException ex){ // handle your exception
                                System.out.println("Error in Line "+lineCounter 
                                        +" : "+line);
                                break;
                        }
                    }
                default:{
                    System.out.println("Not an order or shipment at Line: "
                            +line);
                }
            }
            }
        }
    
        //checks the queue for any remaining orders that need processing
        if(order.peek()!=null){
            outputFileBuffer.write("Orders that are waiting to be processed:\n");
            //continuously check for remaining orders in the queue
            while(order.peek()!=null){
                widgetOrder=order.peek();
                //write the remaining order to output file
                outputFileBuffer.write(widgetOrder.toString()+eol);
                //remove the fully process from the WarehouseQueue 
                order.dequeue();
            }
        }            
        //close output file after processing is finish.
        outputFileBuffer.close();
        //closes input file after processing is finish
        inputFileBuffer.close();            
    }
    
    /**
     * Process a shipment when it arrives. The shipment is either added to an 
     * order or place on a stack for later order(s). 
     * @throws IOException 
     */   
    private void processShipment() throws IOException{
        //A double to store the cost of a order amount and cost of widget.
        double cost;
        //check if total amount of widgets is zero
        if(totalOrderOfWidgets==0){   
            //increase the total amount of shipment in the warehouse
            totalShipmentOfWidgets +=widgetShipment.getAmountOfWidget();
            //add the new shipment to the shipment stack 
            shipment.push(widgetShipment);           
        }
        //check if the new shipment widgets is greater than the total order widgets
        else if(totalOrderOfWidgets<widgetShipment.getAmountOfWidget()){            
            do{
                //get the first Order Objetc in the WarehouseQueue
                widgetOrder = order.peek();
                //checks if the front of the queue is empty
                if(widgetOrder==null){
                    throw new NoSuchElementException("Underflow Exception");
                }
                int newShipmentAmount = widgetShipment.getAmountOfWidget();
                //calculate the cost order amount
                cost = (widgetShipment.getCostOfWidget()*
                        widgetOrder.getRemainingWidgets())*TAX;
                //set the order cost
                widgetOrder.setCostOfWidget(cost);
                widgetOrder.addShipment(widgetOrder.getRemainingWidgets(),
                widgetShipment.getCostOfWidget(),widgetShipment.getVendor());
                // decrement the total order amount but the remaining amount
                //of order widgets
		totalOrderOfWidgets -=widgetOrder.getRemainingWidgets();
                widgetShipment.setAmountOfWidget(newShipmentAmount
                        -widgetOrder.getRemainingWidgets());
                
                //write order to output file
                outputFileBuffer.write(widgetOrder.toString()+eol);
                //remove the fully process from the WarehouseQueue 
		order.dequeue();
            }
            while(totalOrderOfWidgets>0);
            if(widgetShipment.getAmountOfWidget()>0){
                //shipments that still have widgets are push to the 
                //WarehouseStack
		shipment.push(widgetShipment);
                //increment the total shipment widgets by the remaining 
                // new shipment about
                totalShipmentOfWidgets=widgetShipment.getAmountOfWidget();
            }
        }
        //check if total amount of order widgets are greater than/equal to
        //new shipment 
        else if(totalOrderOfWidgets>=widgetShipment.getAmountOfWidget()){
            
            do{
                widgetOrder = order.peek();
                //checks if the front of the queue is empty
                if(widgetOrder==null){
                    throw new NoSuchElementException("Underflow Exception");
                }
                int orderAmount= widgetOrder.getRemainingWidgets(); 
                int shipmentAmount= widgetShipment.getAmountOfWidget();
                if(orderAmount<=shipmentAmount){
                //calculate the cost order amount
                cost = (widgetShipment.getCostOfWidget()*
                        widgetOrder.getRemainingWidgets())*TAX;
                //set the cost of the order
                widgetOrder.setCostOfWidget(cost);
                //decrement total amount of order
                widgetOrder.addShipment(widgetOrder.getRemainingWidgets(),
                widgetShipment.getCostOfWidget(),widgetShipment.getVendor());
                totalOrderOfWidgets -=widgetOrder.getRemainingWidgets();
                //set new shipment amount new shipment
                widgetShipment.setAmountOfWidget(widgetShipment.getAmountOfWidget()
                        -orderAmount);
                //decrement the remaining order amount for the order
                widgetOrder.setRemainingWidgets(orderAmount);
                outputFileBuffer.write(widgetOrder.toString()+eol);
                //remove first object from queue
		order.dequeue();
                }
                //check if the first object in the queue remain amount is less
                //than the new shipment widget amount
                else if(orderAmount>shipmentAmount){
                    //calculate the cost of the order amount and set the order
                    //cost
                    cost = (widgetShipment.getCostOfWidget()*
                        shipmentAmount)*TAX;                    
                    widgetOrder.setCostOfWidget(cost);  
                    widgetOrder.addShipment(shipmentAmount,widgetShipment.getCostOfWidget(),
                            widgetShipment.getVendor());
                    totalOrderOfWidgets -=shipmentAmount;                
                    widgetShipment.setAmountOfWidget(widgetShipment.getAmountOfWidget()
                            -widgetOrder.getRemainingWidgets());
                    widgetOrder.setRemainingWidgets(shipmentAmount);
                
                }
            }
            while(widgetShipment.getAmountOfWidget()>0);
            if(widgetShipment.getAmountOfWidget()>0){
                //push the element to the stack and increment the total amount
                //of shipment widgets
                shipment.push(widgetShipment);
                totalShipmentOfWidgets=widgetShipment.getAmountOfWidget();
            }
        }   
    }
    
    /**
     * Process an order when it arrives. The order is either added to the
     * WarehouseQueue or outputted to the output file. 
     * @throws IOException 
     */
    private void processOrder() throws IOException{
        double cost;
        //insert and increment the total order of widgets if 
        //shipment total is zero
        if(totalShipmentOfWidgets==0){
            order.enqueue(widgetOrder); 
            totalOrderOfWidgets +=widgetOrder.getRemainingWidgets();            
        }
        //check if the shipment total is less than remaining widgets order
        else if(totalShipmentOfWidgets<widgetOrder.getRemainingWidgets()){
            //continuously process an order until the shipment total is zero
            //several shipment may be on the stack that can process an order
            do{
                widgetShipment = shipment.peek();
                //checks if the top of the stack is empty
                if(widgetShipment==null){
                    throw new NoSuchElementException("Underflow Exception");
                }
                cost = (widgetShipment.getAmountOfWidget()*
                        widgetShipment.getCostOfWidget())*TAX;
                widgetOrder.setCostOfWidget(cost);
                widgetOrder.addShipment(widgetShipment.getAmountOfWidget(),
                    widgetShipment.getCostOfWidget(),widgetShipment.getVendor());
                totalShipmentOfWidgets -= widgetShipment.getAmountOfWidget();
                totalOrderOfWidgets = widgetOrder.getRemainingWidgets()-
                        widgetShipment.getAmountOfWidget();
                widgetOrder.setRemainingWidgets(widgetShipment.getAmountOfWidget());
                shipment.pop();                
            }
            while(totalShipmentOfWidgets>0);
            //the processed order is then added to the queue
            order.enqueue(widgetOrder);            
        }
        //check if the shipment total is greater than/equal to the new order
        //widget
        else if(totalShipmentOfWidgets>=widgetOrder.getRemainingWidgets()){
            //amount of widgets order remaining to be processed.
            int remainingAmount =widgetOrder.getRemainingWidgets();
            //continuously process an order if the remaining widgets in an 
            //order is not zero
            do{
                widgetShipment = shipment.peek();
                //checks if the top of the stack is empty
                if(widgetShipment==null){
                    throw new NoSuchElementException("Underflow Exception");
                }
                int shipmentAmount = widgetShipment.getAmountOfWidget();          
                if(shipmentAmount<=remainingAmount){                    
                    cost=(shipmentAmount*widgetShipment.getCostOfWidget())*TAX;
                    widgetOrder.setCostOfWidget(cost);
                    widgetOrder.addShipment(shipmentAmount,widgetShipment.getCostOfWidget(),
                        widgetShipment.getVendor());
                    remainingAmount-=shipmentAmount;                    
                    totalShipmentOfWidgets -=shipmentAmount;                      
                    shipment.pop(); 
                }     
                else if(shipmentAmount>remainingAmount){                    
                    cost =(remainingAmount*widgetShipment.getCostOfWidget())*TAX;
                    widgetOrder.setCostOfWidget(cost);  
                    widgetOrder.addShipment(remainingAmount,widgetShipment.getCostOfWidget(),
                        widgetShipment.getVendor());
                    totalShipmentOfWidgets-=remainingAmount;
                    widgetShipment.setAmountOfWidget(shipmentAmount-remainingAmount);                    
                    remainingAmount = 0;
                }
            }while(remainingAmount>0);
            //write the fully processed order to the output file             
            outputFileBuffer.write(widgetOrder.toString()+eol);
        }      
            
    }    
}

